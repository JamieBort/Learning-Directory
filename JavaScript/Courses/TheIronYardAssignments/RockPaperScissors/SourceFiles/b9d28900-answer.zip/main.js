// Variables
const computer = 'paper';
let me = 'rock'; // Change this to test your code


if (me === 'paper') {
  console.log('Looks like a tie!');
} else if (me === 'rock') {
  console.log('Computer Wins');
} else if (me === 'scissors'){
  console.log('I Win!');
}