package io.javabrains;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseApiDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
