const express = require('express');
const app = express();

// configure the / path
app.get('/', function (req, res) {
  res.send(`
    <h1>Hello, World</h1>
    <a href="food">Go to Food</a>
  `);
});

// show some food
app.get('/food', function (req, res) {
  res.send(`
    <h1>Hello, Food</h1>
    <a href="/">Go to Home</a>
  `);
});

// run the app on port 3000
app.listen(3000, function(){
  console.log('Successfully started express app');
});
