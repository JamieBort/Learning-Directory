const express = require('express');
const moment = require('moment');
const mustacheExpress = require('mustache-express');

const app = express();

// tell express to use mustache
app.engine('mustache', mustacheExpress());
app.set('views', './views');
app.set('view engine', 'mustache');

app.use(express.static('public'));

// use a render method for template
app.get('/', function (req, res) {
  res.render('home', {
    formattedDate: moment().format(),
    fruits: ['apple', 'orange', 'pear']
  });
});

// run the app on port 3000
app.listen(3000, function(){
  console.log('Successfully started express app');
});
