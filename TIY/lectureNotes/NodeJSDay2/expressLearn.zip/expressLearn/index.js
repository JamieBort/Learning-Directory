// Popping the code from one file to an object
const example = require('./module');

console.log(example);
