// module.exports.name='Kaitlyn';
//
// module.exports.height= 7;
//
// module.exports.sayHi= function(){
//   return 'Hellloooo';
// };

let person = {
  name: 'Brandon',
  height: 7.5,
  sayHi: function(){
    return 'Hiya'
  }
}

module.exports = person;
